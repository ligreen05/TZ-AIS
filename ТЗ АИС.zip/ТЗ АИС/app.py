import os
from flask import Flask, render_template
from config import Config
from extensions import db, login_manager, csrf
from utils.logging import get_logger


def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    db.init_app(app)
    login_manager.init_app(app)
    csrf.init_app(app)

    # Security headers
    @app.after_request
    def security_headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Permissions-Policy"] = "geolocation=(), microphone=(), camera=()"
        return response

    # Jinja-фильтры
    @app.template_filter("qty")
    def fmt_qty(v):
        if v is None:
            return "0"
        s = f"{float(v):.3f}".rstrip("0").rstrip(".")
        return s or "0"

    # Blueprints
    from blueprints.auth import auth_bp
    from blueprints.main import main_bp
    from blueprints.products import products_bp
    from blueprints.operations import operations_bp
    from blueprints.inventory import inventory_bp
    from blueprints.reports import reports_bp
    from blueprints.admin import admin_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(products_bp, url_prefix="/products")
    app.register_blueprint(operations_bp, url_prefix="/operations")
    app.register_blueprint(inventory_bp, url_prefix="/inventory")
    app.register_blueprint(reports_bp, url_prefix="/reports")
    app.register_blueprint(admin_bp, url_prefix="/admin")

    # Ошибки
    @app.errorhandler(400)
    def bad_request(e):
        return render_template("error.html", code=400, message="Некорректный запрос"), 400

    @app.errorhandler(403)
    def forbidden(e):
        return render_template("error.html", code=403, message="Доступ запрещён"), 403

    @app.errorhandler(404)
    def not_found(e):
        return render_template("error.html", code=404, message="Страница не найдена"), 404

    @app.errorhandler(500)
    def server_error(e):
        db.session.rollback()
        get_logger().exception("Internal server error")
        return render_template("error.html", code=500, message="Внутренняя ошибка сервера"), 500

    return app


app = create_app()

if __name__ == "__main__":
    app.run(debug=False, host="0.0.0.0", port=5006)