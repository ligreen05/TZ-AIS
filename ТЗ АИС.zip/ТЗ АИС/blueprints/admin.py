from flask import Blueprint, render_template, request, redirect, url_for, flash, abort
from flask_login import login_required, current_user

from extensions import db
from models import User, Role, ActionLog
from utils import require_role, paginate, log_action

admin_bp = Blueprint("admin", __name__)


@admin_bp.route("/users")
@login_required
@require_role("admin")
def users():
    pag = paginate(User.query.order_by(User.username))
    return render_template("admin/users.html", pagination=pag,
                           roles=Role.query.order_by(Role.name).all())


@admin_bp.route("/users/new", methods=["POST"])
@login_required
@require_role("admin")
def user_new():
    try:
        u = User(
            username=request.form["username"].strip(),
            full_name=request.form["full_name"].strip(),
            email=request.form["email"].strip(),
            role_id=int(request.form["role_id"]),
        )
        u.set_password(request.form["password"])
        db.session.add(u)
        db.session.flush()
        log_action("create_user", "User", u.id, u.username)
        db.session.commit()
        flash("Пользователь создан", "success")
    except Exception as e:
        db.session.rollback()
        flash(f"Ошибка: {e}", "danger")
    return redirect(url_for("admin.users"))


@admin_bp.route("/users/<int:uid>/toggle", methods=["POST"])
@login_required
@require_role("admin")
def user_toggle(uid):
    u = db.session.get(User, uid) or abort(404)
    if u.id == current_user.id:
        flash("Нельзя заблокировать самого себя", "warning")
    else:
        u.is_active_flag = not u.is_active_flag
        log_action("toggle_user", "User", u.id, f"active={u.is_active_flag}")
        db.session.commit()
        flash("Статус пользователя изменён", "info")
    return redirect(url_for("admin.users"))


@admin_bp.route("/log")
@login_required
@require_role("admin")
def log():
    pag = paginate(ActionLog.query.order_by(ActionLog.created_at.desc()), per_page=50)
    return render_template("admin/log.html", pagination=pag)