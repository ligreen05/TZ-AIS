from decimal import Decimal
from app import app
from extensions import db
from models import (
    Role, User, Category, Unit, Warehouse, StorageLocation,
    Supplier, Customer, Product, Stock,
)


def seed():
    with app.app_context():
        db.drop_all()
        db.create_all()

        roles = {
            "storekeeper": Role(code="storekeeper", name="Кладовщик"),
            "operator": Role(code="operator", name="Оператор склада"),
            "manager": Role(code="manager", name="Менеджер по продажам"),
            "head": Role(code="head", name="Руководитель склада"),
            "admin": Role(code="admin", name="Администратор"),
        }
        db.session.add_all(roles.values())
        db.session.flush()

        for uname, fio, mail, pwd, role_code in [
            ("admin", "Администратор Системы", "admin@example.com", "admin123", "admin"),
            ("sklad", "Иванов И.И.", "sklad@example.com", "sklad123", "storekeeper"),
            ("oper", "Петров П.П.", "oper@example.com", "oper123", "operator"),
            ("menedzher", "Сидоров С.С.", "m@example.com", "m123", "manager"),
            ("rukov", "Кузнецов К.К.", "r@example.com", "r123", "head"),
        ]:
            u = User(username=uname, full_name=fio, email=mail, role=roles[role_code])
            u.set_password(pwd)
            db.session.add(u)

        db.session.flush()

        units = [Unit(name=n) for n in ["шт", "кг", "л", "м", "упак"]]
        cats = [Category(name=n) for n in
                ["Электроника", "Бытовая химия", "Продукты", "Инструменты", "Прочее"]]
        db.session.add_all(units + cats)
        db.session.flush()

        w1 = Warehouse(name="Основной склад", address="г. Москва, ул. Складская, 1")
        w2 = Warehouse(name="Резервный склад", address="г. Москва, ул. Запасная, 5")
        db.session.add_all([w1, w2])
        db.session.flush()

        locs = [
            StorageLocation(code=f"{z}-{n:02d}", warehouse=w)
            for w in (w1, w2) for z in ("A", "B", "C") for n in range(1, 4)
        ]
        db.session.add_all(locs)

        sups = [
            Supplier(name="ООО «Поставщик-1»", inn="7701234567"),
            Supplier(name="ООО «Поставщик-2»", inn="7702345678"),
        ]
        custs = [
            Customer(name="ООО «Покупатель-1»", inn="7801234567"),
            Customer(name="ООО «Покупатель-2»", inn="7802345678"),
        ]
        db.session.add_all(sups + custs)
        db.session.flush()

        products = [
            Product(sku="EL-001", name="Клавиатура USB", category=cats[0], unit=units[0], min_stock=10),
            Product(sku="EL-002", name="Мышь оптическая", category=cats[0], unit=units[0], min_stock=15),
            Product(sku="EL-003", name='Монитор 24"', category=cats[0], unit=units[0], min_stock=3),
            Product(sku="HC-001", name="Средство для мытья полов, 5 л", category=cats[1], unit=units[2], min_stock=5),
            Product(sku="PR-001", name="Сахар, 1 кг", category=cats[2], unit=units[1], min_stock=20),
            Product(sku="PR-002", name="Кофе молотый, 250 г", category=cats[2], unit=units[4], min_stock=10),
            Product(sku="IN-001", name="Отвёртка крестовая", category=cats[3], unit=units[0], min_stock=5),
        ]
        db.session.add_all(products)
        db.session.flush()

        for p in products:
            for loc in locs[:3]:
                db.session.add(Stock(product=p, warehouse=w1, location=loc,
                                     quantity=Decimal("50"), reserved=Decimal("0")))

        db.session.commit()
        print("✅ БД создана.")
        for uname, _, _, pwd, _ in [
            ("admin", "", "", "admin123", ""),
            ("sklad", "", "", "sklad123", ""),
            ("oper", "", "", "oper123", ""),
            ("menedzher", "", "", "m123", ""),
            ("rukov", "", "", "r123", ""),
        ]:
            print(f"  {uname} / {pwd}")


if __name__ == "__main__":
    seed()