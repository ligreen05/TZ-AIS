from contextlib import contextmanager
from extensions import db
from utils.logging import get_logger


@contextmanager
def transaction():
    """
    Контекстный менеджер транзакций.
    При исключении — rollback и проброс ошибки.
    """
    try:
        yield
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        get_logger().exception(f"Transaction failed: {e}")
        raise